import os
import pandas as pd
import logging
from get_main_body import get_all_main_body
from get_comments_level_one import get_all_level_one
from get_comments_level_two import get_all_level_two
import time
from random import randint

logging.basicConfig(level=logging.INFO)


class WBParser:
    def __init__(self, cookie):
        self.cookie = cookie
        self.base_dir = "./WBData1024"

        os.makedirs(self.base_dir, exist_ok=True)
        os.makedirs(f"{self.base_dir}/Comments_level_1", exist_ok=True)
        os.makedirs(f"{self.base_dir}/Comments_level_2", exist_ok=True)

        self.main_body_all_filepath = f"{self.base_dir}/all_main_body.csv"
        self.comments_level_1_all_filepath = f"{self.base_dir}/all_comments_level_1.csv"
        self.comments_level_2_all_filepath = f"{self.base_dir}/all_comments_level_2.csv"

        self.main_body_all_data = []
        self.comments_level_1_all_data = []
        self.comments_level_2_all_data = []

    def get_main_body(self, q, kind):
        data = get_all_main_body(q, kind, self.cookie)
        data = data.reset_index(drop=True).astype(str).drop_duplicates()
        self.main_body_all_data.append(data)
        return data

    def get_comments_level_one(self, main_body):
        data_list = []

        logging.info(f"主体内容一共有{main_body.shape[0]:5d}个，现在开始解析...")

        for ix in range(main_body.shape[0]):
            uid = main_body.iloc[ix]["uid"]
            mid = main_body.iloc[ix]["mid"]
            final_file_path = f"{self.base_dir}/Comments_level_1/{uid}_{mid}.csv"

            if os.path.exists(final_file_path) and os.path.getsize(final_file_path) > 0:
                try:
                    length = pd.read_csv(final_file_path, encoding="utf_8_sig").shape[0]
                    if length > 0:
                        continue
                except pd.errors.EmptyDataError:
                    logging.warning(f"文件 {final_file_path} 为空，跳过读取。")

            logging.info(f"解析uid：{uid}，mid：{mid}的评论...")
            try:
                data = get_all_level_one(uid=uid, mid=mid, cookie=self.cookie)
                data.drop_duplicates(inplace=True)
                data.to_csv(final_file_path, encoding="utf_8_sig", index=False)
                data_list.append(data)
            except Exception as e:
                logging.error(f"解析uid：{uid}，mid：{mid}的评论时出错：{e}")

        logging.info(f"主体内容一共有{main_body.shape[0]:5d}个，已经解析完毕！")
        if data_list:
            data = pd.concat(data_list).reset_index(drop=True).astype(str).drop_duplicates()
            self.comments_level_1_all_data.append(data)
            return data
        return None

    def get_comments_level_two(self, comments_level_1_data):
        if comments_level_1_data is None:
            logging.info("没有一级评论数据，跳过解析二级评论。")
            return

        data_list = []

        logging.info(f"一级评论一共有{comments_level_1_data.shape[0]:5d}个，现在开始解析...")

        for ix in range(comments_level_1_data.shape[0]):
            main_body_uid = comments_level_1_data.iloc[ix]["main_body_uid"]
            mid = comments_level_1_data.iloc[ix]["mid"]
            final_file_path = f"{self.base_dir}/Comments_level_2/{main_body_uid}_{mid}.csv"

            if os.path.exists(final_file_path) and os.path.getsize(final_file_path) > 0:
                try:
                    length = pd.read_csv(final_file_path, encoding="utf_8_sig").shape[0]
                    if length > 0:
                        continue
                except pd.errors.EmptyDataError:
                    logging.warning(f"文件 {final_file_path} 为空，跳过读取。")

            logging.info(f"解析一级评论main_body_uid：{main_body_uid}，mid：{mid}的二级评论...")
            try:
                data = get_all_level_two(uid=main_body_uid, mid=mid, cookie=self.cookie)
                data.drop_duplicates(inplace=True)
                data.to_csv(final_file_path, encoding="utf_8_sig", index=False)
                data_list.append(data)
            except Exception as e:
                logging.error(f"解析一级评论main_body_uid：{main_body_uid}，mid：{mid}的二级评论时出错：{e}")

        logging.info(f"一级评论一共有{comments_level_1_data.shape[0]:5d}个，已经解析完毕！")
        if data_list:
            data = pd.concat(data_list).reset_index(drop=True).astype(str).drop_duplicates()
            self.comments_level_2_all_data.append(data)
            return data
        return None

    def parse_topic(self, q, kind):
        logging.info(f"开始解析话题：{q}，类型：{kind}")
        main_body = self.get_main_body(q, kind)
        comments_level_1_data = self.get_comments_level_one(main_body)
        self.get_comments_level_two(comments_level_1_data)
        logging.info(f"话题：{q}，类型：{kind}，解析完成")

    def save_all_data(self):
        if self.main_body_all_data:
            main_body_all_df = pd.concat(self.main_body_all_data).reset_index(drop=True).astype(str).drop_duplicates()
            main_body_all_df.to_csv(self.main_body_all_filepath, encoding="utf_8_sig", index=False)

        if self.comments_level_1_all_data:
            comments_level_1_all_df = pd.concat(self.comments_level_1_all_data).reset_index(drop=True).astype(
                str).drop_duplicates()
            comments_level_1_all_df.to_csv(self.comments_level_1_all_filepath, encoding="utf_8_sig", index=False)

        if self.comments_level_2_all_data:
            comments_level_2_all_df = pd.concat(self.comments_level_2_all_data).reset_index(drop=True).astype(
                str).drop_duplicates()
            comments_level_2_all_df.to_csv(self.comments_level_2_all_filepath, encoding="utf_8_sig", index=False)


if __name__ == "__main__":
    topics = [
        ("#教育部发文促进高校毕业生就业#", "热门"),
        # ("#大学生就业# ", "综合"),
        # ("#研究生就业# ", "综合"),
        # ("#硕士生就业# ", "综合"),
        # ("#博士生就业# ", "综合"),
        # ("#本科生就业# ", "综合"),
        # ("#为什么研究生就业难于本科生# ", "综合"),
       #("#北大研究生研究生毕业留校在食堂工作#","综合"),
       #("#研究生毕业五年没找到合适工作#","综合"),
        #("#研究生毕业第一份工作在船上#", "综合"),
       #("#一研究生毕业5年没找到工作#", "综合"),
        # 添加更多的话题
    ]
    cookie = "SINAGLOBAL=7462700194569.889.1758543902941; SCF=AhqvF-ZBJQvh3CXFexObHSqIt46i0wyDnDpjVo4j36IAlCFUUy8y3DNJPurHHX6v4qoReMLobdCgSejaRtfokHM.; SUB=_2A25F_qSSDeRhGeFH6VoV9CvIzj6IHXVndbharDV8PUNbmtAbLXHhkW9Ne5DijIQsEdp9z0gMZ_hhFF3QUEw_QyfV; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WhVSpCT11H_oVm6kpq_ZpeN5JpX5KzhUgL.FoM4eonXSh-XSKz2dJLoIp7LxKML1KBLBKnLxKqL1hnLBoM4e0MpSh-RSoM0; ALF=02_1763860930; XSRF-TOKEN=VSgOIzWvwztcn_X07ziBl12x; _s_tentry=weibo.com; Apache=2404412716405.593.1761269117826; ULV=1761269117884:3:2:2:2404412716405.593.1761269117826:1760715115311; WBPSESS=EXr3sHzAD0trtTuy4N7_XOLnxtoYfkbb8tn3B_ZWu4utvsT5aS_9_TRQ-nXjA-syjOmOJ-B7slBUXjK07eDd1WdzSbqlzwnxWJe8FwqRmRxQv5LtglvdGtEtYGkMlu4I25atOp_oZwxvC7lTwDUzOg=="
    wbparser = WBParser(cookie)

    for topic, kind in topics:
        wbparser.parse_topic(topic, kind)
        # 随机延迟
        # time.sleep(randint(3, 6))

    wbparser.save_all_data()
